from django.apps import AppConfig


class CoursesConfig(AppConfig):
    name = 'apps.courses'
    verbose_name = "课程管理"
